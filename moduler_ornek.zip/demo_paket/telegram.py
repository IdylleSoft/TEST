import requests


def mesaj_gonder(token, chat_id, mesaj):
    try:
        yanit = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": mesaj},
            timeout=30,
        )
    except requests.RequestException:
        raise RuntimeError("Telegram bağlantısı kurulamadı veya zaman aşımına uğradı.") from None

    try:
        sonuc = yanit.json()
    except ValueError:
        raise RuntimeError(f"Geçersiz Telegram yanıtı (HTTP {yanit.status_code}).") from None

    if not yanit.ok or not sonuc.get("ok"):
        raise RuntimeError(sonuc.get("description", "Mesaj gönderilemedi."))
    return sonuc["result"]["message_id"]
