import time

from .ayarlar import BOT_TOKEN, CHAT_ID, TEST_MESAJI, BEKLEME_SANIYE
from .telegram import mesaj_gonder


def main():
    print("Modüler Telegram döngüsü başladı. Durdurmak için Ctrl+C.", flush=True)
    if not BOT_TOKEN.strip() or not CHAT_ID.strip():
        print("Bot tokenı ve chat ID boş bırakılamaz.", flush=True)
        return

    sayac = 1
    try:
        while True:
            try:
                mesaj_id = mesaj_gonder(BOT_TOKEN, CHAT_ID, f"{sayac}. {TEST_MESAJI}")
                print(f"{sayac}. mesaj gönderildi. Mesaj ID: {mesaj_id}", flush=True)
                sayac += 1
            except RuntimeError as hata:
                print(f"Hata: {hata}", flush=True)
            time.sleep(BEKLEME_SANIYE)
    except KeyboardInterrupt:
        print("\nMesaj gönderimi durduruldu.", flush=True)
