"""Modüler çalıştırma örneği."""
